<nav>
  <ul class="gnb">
    <li>
      <a class="gnb_sub" href="">회사소개</a>
      <ul class="gnb_detail">
        <li><a href="">경영이념</a></li>
        <li><a href="">사업분야</a></li>
        <li><a href="">히스토리</a></li>
      </ul>
    </li>
    <li>
      <a class="gnb_sub" href="./product.php?id=all-category">제품소개</a>
      <ul class="gnb_detail">
        <li><a href="">전체보기</a></li>
        <li><a href="./product.php?id=milk">우유/치즈</a></li>
        <li><a href="./product.php?id=ice">아이스크림</a></li>
        <li><a href="./product.php?id=yogurt">발효유</a></li>
      </ul>
    </li>
    <li>
      <a class="gnb_sub" href="">투자정보</a>
      <ul class="gnb_detail">
        <li><a href="">재무정보</a></li>
        <li><a href="">주식정보</a></li>
        <li><a href="">전자공고</a></li>
      </ul>
    </li>
    <li>
      <a class="gnb_sub" href="">홍보</a>
      <ul class="gnb_detail">
        <li><a href="">유튜브</a></li>
        <li><a href="">SNS</a></li>
      </ul>
    </li>
    <li>
      <a class="gnb_sub" href="">고객센터</a>
      <ul class="gnb_detail">
        <li><a href="">고객상담</a></li>
        <li><a href="">안전신문고</a></li>
      </ul>
    </li>
  </ul>
</nav>