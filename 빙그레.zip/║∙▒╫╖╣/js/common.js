
export let scrollY = window.scrollY






window.addEventListener('resize',e=>{
  scrollY = window.scrollY
})

window.addEventListener('scroll',e=>{
  scrollY = window.scrollY
})


