document.querySelectorAll(".gnb_detail").forEach(async (v) => {
  await v.setAttribute("data-height", v.offsetHeight);
  v.style.height = 0;
});

document.querySelectorAll(".gnb_sub").forEach((v) => {
  v.addEventListener("click", (e) => {
    e.preventDefault(); //삭제
    document.querySelectorAll(".gnb_detail").forEach((v) => {
      v.classList.remove("active");
      v.style.height = 0;
    });
    let menu = e.target.parentElement.children[1];
    menu.classList.add("active");
    menu.style.height = menu.getAttribute("data-height") + "px";
  });
});

window.addEventListener("resize", (e) => {
  document.querySelectorAll(".gnb_detail").forEach(async (v) => {
    v.style.height = await "auto";
    v.classList.remove("active");
    v.setAttribute("data-height", v.offsetHeight);
    v.style.height = 0;
  });
});

//max-lg 메뉴버튼
document.querySelector("div.menu_btn").addEventListener("click", (e) => {
  e.currentTarget.classList.toggle("active");
  document.querySelector(".side_header").classList.toggle("active");
});

//min-lag header hover
document.querySelector('header nav').addEventListener('mouseenter',e=>{
  document.querySelector('header').classList.add('active')
})
document.querySelector('header').addEventListener('mouseleave',e=>{
  document.querySelector('header').classList.remove('active')
})

window.addEventListener('scroll',e=>{
  console.log(window.scrollY)
  if(window.scrollY>80){
    document.querySelector('.topBtn').style.cursor='pointer'
    document.querySelector('.topBtn').style.opacity=1
    document.querySelector('header').style.backgroundColor='var(--l-gray)'
  }
  else{
    document.querySelector('.topBtn').style.cursor='default'
    document.querySelector('.topBtn').style.opacity=0
    document.querySelector('header').style.backgroundColor='transparent'
  }
})
document.querySelector('.topBtn').addEventListener('click',e=>{
  if(window.scrollY>100){
    window.scrollTo({
      top:0,
      behavior:"smooth"
    })
  }
})