<?php include "header.php" ?>
  <script src="./js/list.js" type="module"></script>
  <figure class="slide">
    <!-- 동적생성 -->
  </figure>

  <main class="list-content">
    <h2 class="list-title">최신영화</h2>

    <section class="common-section movie-grid-section wrap-section list-section">
      <h2>
        <i class="fa-solid fa-photo-film"></i>
        <em><!-- 동적생성 --></em>
      </h2>
      <div class="grid-container"></div>
    </section>
    <nav class="paging"> 
    </nav>
  </main><!--list-content-->

<?php include "footer.php" ?>