<script src="./js/video-modal.js" type="module"></script>
<section class="video-modal">
  <img class="youtube-ratio" src="./img/youtube-ratio.jpg" alt="">
  <iframe src="" allowfullscreen></iframe>
  <button class="modal-close-btn">
    <i class="fa-solid fa-circle-xmark"></i>
  </button>
</section><!--video-modal-->